import { Stationary } from './stationary';

export const STATIONARIES: Stationary[] = [
  { id: 101, product: 'Pen Set', price:60, discount:'20 %',imageUrl:'assets/image/pen.jpg'},
  { id: 102, product: 'Pencil Box', price:40, discount:'15 %',imageUrl:'assets/image/pencil.jpg' },
  { id: 103, product: 'Books', price:50, discount:'15 %',imageUrl:'assets/image/books.jpg' },
  { id: 104, product: 'Sketch Pens', price:700, discount:'30 %',imageUrl:'assets/image/sketchpens.jpg' }
]