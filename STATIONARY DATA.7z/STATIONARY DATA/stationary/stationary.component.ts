import { Component, OnInit } from '@angular/core';
import {Stationary} from '../stationary';
import {STATIONARIES} from '../mock-stationaries';

@Component({
  selector: 'app-stationary',
  templateUrl: './stationary.component.html',
  styleUrls: ['./stationary.component.css']
})
export class StationaryComponent implements OnInit {

   stationaries=STATIONARIES;
  constructor() { }

  ngOnInit() {
  }

}
