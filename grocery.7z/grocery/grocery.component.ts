import { Component, OnInit } from '@angular/core';
import {Grocery} from '../grocery';
import {GROCERIES} from '../mock-groceries';


@Component({
  selector: 'app-grocery',
  templateUrl: './grocery.component.html',
  styleUrls: ['./grocery.component.css']
})
export class GroceryComponent implements OnInit {

 groceries=GROCERIES;
  constructor() { }
 
  ngOnInit() {
   
  }
 
}
